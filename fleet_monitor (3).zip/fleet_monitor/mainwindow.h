#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QGraphicsEllipseItem>
#include <QTimer>
#include <QList>
#include <QPointF>
#include <QSoundEffect>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

// информация об одном БПЛА
struct DroneInfo {
    int id;                       // номер
    int battery;                  // заряд в процентах
    bool online;                  // на связи или нет
    QPointF pos;                  // координаты на карте
    QGraphicsEllipseItem *item;   // кружок на сцене
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void updateFleet();           // обновление телеметрии (по таймеру)
    void on_btnPause_clicked();   // кнопка "Пауза"
    void on_btnReset_clicked();   // кнопка "Сброс"

private:
    void createFleet();           // создать 6 БПЛА заново

    Ui::MainWindow *ui;
    QGraphicsScene *scene;
    QTimer *timer;
    QList<DroneInfo> fleet;       // весь парк БПЛА
    QSoundEffect *offlineSound;   // звук, когда БПЛА отключился
};

#endif // MAINWINDOW_H
