#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // создаем сцену
    scene = new QGraphicsScene(0, 0, 800, 600);
    ui->graphicsView->setScene(scene);

    // начальные координаты
    x = 50;
    y = 50;

    // рисуем бпла (красный круг)
    uav = scene->addEllipse(0, 0, 20, 20);
    uav->setBrush(Qt::red);
    uav->setPos(x, y);

    // таймер
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(moveUAV()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::moveUAV()
{
    // едем по квадрату
    if (y == 50 && x < 250) {
        x = x + 2;
    }
    else if (x == 250 && y < 250) {
        y = y + 2;
    }
    else if (y == 250 && x > 50) {
        x = x - 2;
    }
    else if (x == 50 && y > 50) {
        y = y - 2;
    }

    // меняем цвет
    if (y < 300) {
        uav->setBrush(Qt::blue);
    }
    else {
        uav->setBrush(Qt::red);
    }

    uav->setPos(x, y);
    ui->labelStatus->setText("X = " + QString::number(x) + " Y = " + QString::number(y));
}

void MainWindow::on_btnStart_clicked()
{
    timer->start(20);
}
